package com.example.grocerystore;

public class Constants {
    //product categories
    public static final String[] productCategory = {
            "Beverages",
            "Beauty & Personal Care",
            "Baby Kids",
            "Biscuits Snacks &Chocolates",
            "Breakfast &Dairy",
            "Cooking Needs",
            "Frozen Food",
            "Fruits",
            "others"
    };

    public static final String[] productCategory1 = {
            "All",
            "Beverages",
            "Beauty & Personal Care",
            "Baby Kids",
            "Biscuits Snacks &Chocolates",
            "Breakfast &Dairy",
            "Cooking Needs",
            "Frozen Food",
            "Fruits",
            "others"
    };
}
